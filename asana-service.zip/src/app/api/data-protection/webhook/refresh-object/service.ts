export const refreshDataProtectionObject = async () => {};
