export const deleteDataProtectionObjectPermission = async () => {};
