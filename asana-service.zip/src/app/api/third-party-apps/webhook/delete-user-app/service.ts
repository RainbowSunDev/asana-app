export const deleteThirdPartyAppsUserApp = async () => {};
