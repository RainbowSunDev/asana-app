export const scheduleAuthenticationSyncJobs = async () => {};
